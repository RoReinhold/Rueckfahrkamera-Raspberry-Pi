package de.zimkand.lookbackward2;

import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private WebView webView;
    Socket myAppSocket = null;
    public static String wifiModuleIp = "";
    public static int wifiModulePort = 0;
    public static String CMD = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonNetPsw = (Button) findViewById(R.id.button_NetworkPsw);
        Button buttonNetName = (Button) findViewById(R.id.button_NetworkName);
        buttonNetPsw.setOnClickListener(this);
        buttonNetName.setOnClickListener(this);

        webView = (WebView) findViewById(R.id.webview);
        webView.setInitialScale(1);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        webView.setScrollbarFadingEnabled(false);
        //webView.setWebViewClient(new WebViewClient());
        //Display display = getWindowManager().getDefaultDisplay();
        //int width=display.getWidth();
        String url = "http://192.172.13.1:8080/stream";


        //String data="<html><head><title>Example</title><meta name=\"viewport\"\"content=\"width="+width+", initial-scale=0.65 \" /></head>";
        //data=data+"<body><center><img width=\""+width+"\" src=\""+url+"\" /></center></body></html>";
        // webView.loadData(data, "text/html", null);

        webView.loadUrl(url);
    }

    public void getIPandPort()
    {
        String iPandPort = "192.168.4.1:21567";
        Log.d("MYTEST","IF String: "+ iPandPort);
        String temp[] = iPandPort.split(":");
        wifiModuleIp = temp[0];
        wifiModulePort = Integer.valueOf(temp[1]);
        Log.d("MY TEST","IP:"+wifiModuleIp);
        Log.d("MY TEST","PORT:"+wifiModulePort);
    }

    public class Soket_AsyncTask extends AsyncTask<Void, Void, Void>
    {
        Socket socket;
        @Override
        protected Void doInBackground(Void... params)
        {
            try
            {
                InetAddress inetAddress = InetAddress.getByName(MainActivity.wifiModuleIp);
                socket = new java.net.Socket(inetAddress, MainActivity.wifiModulePort);
                DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeBytes(CMD);
                dataOutputStream.close();
                socket.close();
            }catch(UnknownHostException e)
            {
               e.printStackTrace();
            }catch (IOException e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_NetworkName:
                //Toast.makeText(this, "Network Name button", Toast.LENGTH_SHORT).show();
                AlertDialog.Builder change_Wifi_builder = new AlertDialog.Builder(MainActivity.this);
                final View wifi_name_dialogview = getLayoutInflater().inflate(R.layout.dialog_box_change_wifia_name,null);
                final EditText new_wifi_name = (EditText) wifi_name_dialogview.findViewById(R.id.new_Wifi_name);
                final EditText actual_psw = (EditText) wifi_name_dialogview.findViewById(R.id.confirm_Psw);
                Button confirm_wifiName_btn =  (Button) wifi_name_dialogview.findViewById(R.id.confirm_button_wifiname);

                confirm_wifiName_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view)
                    {
                        if(! new_wifi_name.getText().toString().isEmpty() && !actual_psw.getText().toString().isEmpty())
                        {
                            Toast.makeText(MainActivity.this,"wifi name configure successful, if network turned off and on again", Toast.LENGTH_SHORT).show();
                            getIPandPort();

                            final EditText new_wifi_name = (EditText) wifi_name_dialogview.findViewById(R.id.new_Wifi_name);
                            final EditText actual_psw = (EditText) wifi_name_dialogview.findViewById(R.id.confirm_Psw);


                            CMD = "Name"+","+new_wifi_name.getText().toString()+","+actual_psw.getText().toString();
                            Soket_AsyncTask cmd_wifi_name = new Soket_AsyncTask();
                            cmd_wifi_name.execute();
                        }else{
                            Toast.makeText(MainActivity.this,"emtpy fields", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                change_Wifi_builder.setView(wifi_name_dialogview);
                AlertDialog wifiname_dialog = change_Wifi_builder.create();
                wifiname_dialog.show();

                break;

            case R.id.button_NetworkPsw:
                //Toast.makeText(this, "Network PSW button",Toast.LENGTH_SHORT).show();
                AlertDialog.Builder change_psw_builder = new AlertDialog.Builder(MainActivity.this);
                final View Psw_dialogView = getLayoutInflater().inflate(R.layout.dialog_box_change_psw, null);
                final EditText currentPsw_pswreset = (EditText) Psw_dialogView.findViewById(R.id.current_Psw);
                final EditText newPsw = (EditText) Psw_dialogView.findViewById(R.id.new_Psw);
                final EditText repeatPsw = (EditText) Psw_dialogView.findViewById(R.id.repeat_Psw);
                Button confirmPsw_button = (Button) Psw_dialogView.findViewById(R.id.confirm_button_psw);

                confirmPsw_button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!currentPsw_pswreset.getText().toString().isEmpty() && !newPsw.getText().toString().isEmpty() && !repeatPsw.getText().toString().isEmpty())
                        {
                            getIPandPort();

                            final EditText current_Psw = (EditText)Psw_dialogView.findViewById(R.id.current_Psw);
                            final EditText new_Psw = (EditText)Psw_dialogView.findViewById(R.id.new_Psw);
                            final EditText repeat_new_Psw = (EditText)Psw_dialogView.findViewById(R.id.repeat_Psw);

                            String current_Psw_str = current_Psw.getText().toString();
                            String new_Psw_str = new_Psw.getText().toString();
                            String repeat_new_Psw_str = repeat_new_Psw.getText().toString();

                            if(new_Psw_str.equals(repeat_new_Psw_str))
                            {
                                Toast.makeText(MainActivity.this,"password configuration successful, if network turned off and on again", Toast.LENGTH_SHORT).show();
                                CMD = "Psw"+","+current_Psw_str+","+new_Psw_str;
                                Soket_AsyncTask cmd_wifi_psw = new Soket_AsyncTask();
                                cmd_wifi_psw.execute();
                            }else{
                                Toast.makeText(MainActivity.this,"passwords do not concur", Toast.LENGTH_SHORT).show();
                            }


                        }else{
                            Toast.makeText(MainActivity.this,"Failure: empty fields", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                change_psw_builder.setView(Psw_dialogView);
                AlertDialog psw_dialog = change_psw_builder.create();
                psw_dialog.show();
                break;
        }
    }
}
